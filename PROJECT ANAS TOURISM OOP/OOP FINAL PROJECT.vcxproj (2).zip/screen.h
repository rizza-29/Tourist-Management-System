using namespace std;
int main_screen() {
	int opt;
	cout << "0-End Program" << endl;
	cout << "1-Admin" << endl;
	cout << "2-Customer" << endl;
	cout << "3-Airline" << endl;
	cout << "4-Tour Guide" << endl;
	cout << "5-Hotel Manager" << endl;
	cout << "6-Car Rental" << endl;
	cout << "Please Enter choice number to proceed:";
	cin >> opt;
	return opt;
}
int second_screen() {
	int opt2;
	cout << "0-Go Back" << endl;
	cout << "1-Sign Up" << endl;
	cout << "2-Sign In" << endl;
	cout << "Enter option number to proceed:";
	cin >> opt2;
	return opt2;
}
int admin_screen() {
	int opt3;
	cout << "0-Go Back" << endl;
	cout << "1-Customer Info" << endl;
	cout << "2-Airline Info" << endl;
	cout << "3-Tour Guide Info" << endl;
	cout << "4-Hotel Manager Info" << endl;
	cout << "5-Car Rental Info" << endl;
	cout << "Please Enter choice number to proceed:";
	cin >> opt3;
	return opt3;
}
int customer_screen() {
	int opt3;
	cout << "0-Go Back" << endl;
	cout << "1-Check Packages" << endl;
	cout << "2-Check Car Rentals" << endl;
	cout << "3-Check Tour Guides" << endl;
	cout << "4-Check Profile" << endl;
	cout << "5-Update Profile" << endl;
	cout << "6-Display Bought Packages" << endl;
	cout << "Please Enter choice number to proceed:";
	cin >> opt3;
	return opt3;
}
int customer_package_screen() {
	int opt4;
	cout << "Which Country would you like to check packages of?" << endl;
	cout << "0-Go Back" << endl;
	cout << "1-UAE" << endl;
	cout << "2-Thailand" << endl;
	cout << "3-Turkey" << endl;
	cout << "Enter option number to proceed:";
	cin >> opt4;
	return opt4;
}
int options_screen(){
	int opt;
	cout<<"DO YOU WANT TO AVAIL ANY LISTED SERVICES: "<<endl;
	cout<<"0-GO BACK"<<endl;
	cout<<"1-ADD RENTAL "<<endl;
	cout<<"2-ADD TOUR GUIDE"<<endl;
}
int update_screen(){
	int opt8;
	cout<<"ENTER 0 to go back!!"<<endl;
	cout<<"WHICH DATA DO YOU WANT TO UPDATE: "<<endl;
	cout<<"1-NAME"<<endl;
	cout<<"2-EMAIL"<<endl;
	cout<<"3-PASSWORD"<<endl;							
	cout<<"5-USERNAME"<<endl;
	cout<<"ENTER 0 to go back!!"<<endl;
	cout<<"4-CONTACT NUMBER"<<endl;
	cin>>opt8;
	return opt8;
}
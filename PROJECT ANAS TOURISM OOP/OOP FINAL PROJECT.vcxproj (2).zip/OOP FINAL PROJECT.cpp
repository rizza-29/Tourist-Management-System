#include<iostream>
#include<cstdlib>
#include<string>
#include"screen.h";
#include"AdminClass.h";
#include"CustomerClass.h";
#include"AirlineClass.h";
#include"GuideClass.h";
#include"HotelClass.h";
#include"RentalClass.h";
#include"SignUpFunctions.h";
#include"Packages.h";
using namespace std;
int main() {
	bool flag;
	int num;
	string email, pass, u_name, name;
	admin* adm[10];
	customer* cust[20];
	rental* rent[10];
	guide* tour_guide[10];
	
    adm[admin::get_count()] = new admin("Murtaza Ansari", "1234","Murtaza");
	adm[admin::get_count()] = new admin("Anas Baig", "5678","Anas");
	adm[admin::get_count()] = new admin("Ali Raza", "9012","Ali");
    rent[rental::get_count()]=new rental("USMAN","USAMAN_123",9);
	rent[rental::get_count()]=new rental("JAVAID","JAVAID_123",10);
	rent[rental::get_count()]=new rental("HAMZA","hamza_123",8);
    tour_guide[guide::get_gcount()]=new guide("ANEEQ","ANEEQ_456",7);
	tour_guide[guide::get_gcount()]=new guide("JACK","JACK_789",10);
	tour_guide[guide::get_gcount()]=new guide("MARK","MARK_159",9);
	int opt, opt2, opt3, opt4, opt5, i, j, k;
	cout << "\t\t\tWELCOME TO ANAS TOURISM" << endl;

	do {
		opt = main_screen();
		system("cls");
		do {
			if (opt == 1) {
				opt2 = second_screen();
				system("cls");
				if (opt2 == 1) {
					if (admin::get_count() < 10) {
						cout << "Enter Username of existing Admin to proceed:";
						cin >> u_name;
						for (i = 0;i < admin::get_count();i++) {
							flag = adm[i]->verify(u_name);
							if (flag == true) {
								break;
							}
						}
						if (flag == false) {
							cout << "Existing Admin Sign In Attempt Failed!" << endl;
						}
						if (flag == true) {
							name = input_name();
							u_name = input_username();
							pass = input_pass();
							adm[admin::get_count()] = new admin(name, pass, u_name);
						}
					}
					else {
						cout << "Admin Sign Up is LOCKED!Admin Limit Reached!" << endl;
					}
				}
				if (opt2 == 2) {
					u_name = input_username();
					for (i = 0;i < admin::get_count();i++) {
						flag = adm[i]->verify(u_name);
						if (flag == true) {
							break;
						}
					}
					if (flag == false) {
						cout << "Admin Sign In Attempt Failed!" << endl;
					}
					if (flag == true) {
						do {
							opt3 = admin_screen();
							system("cls");
							if (opt3 == 1) {

							}
							if (opt3 == 2) {

							}
							if (opt3 == 3) {

							}
							if (opt3 == 4) {

							}
							if (opt3 == 5) {

							}
						} while (opt3 != 0);
					}
				}
			}
			if (opt == 2) {
				do {
					opt2 = second_screen();
					system("cls");
					if (opt2 == 1) {
						name = input_name();
						email = input_email();
						num = input_phone_num();
						u_name = input_username();
						pass = input_pass();
						cust[customer::get_count()] = new customer(name, pass, email, num, u_name);
						cout << "Customer Signed Up Successfully" << endl;
					}
					if (opt2 == 2) {
						cout << "Customer Sign In:" << endl;
						u_name = input_username();
						for (i = 0;i < customer::get_count();i++) {
							flag = cust[i]->verify(u_name);
							if (flag == true) {
								break;
							}
						}
						if (flag == false) {
							cout << "Customer Sign In Attempt Failed!" << endl;
						}
						if (flag == true) {
							do {
								opt3 = customer_screen();
								system("cls");
								if (opt3 == 1) {
									do {
										opt4 = customer_package_screen();
										system("cls");
										if (opt4 == 1) {
											opt5 = display_UAE();
											if (opt5 == 0) {
												opt4 = 0;
											}
											if (opt5 == 1) {
												cust[i]->set_type("Premium");
												cust[i]->set_country("UAE");
												cust[i]->set_city1("Dubai");
												cust[i]->set_city2("Abu Dhabi");
												cust[i]->set_city3("Sharjah");
												cust[i]->set_hotel1("Burj Al Arab");
												cust[i]->set_hotel2("Conrad Eitihad Towers");
												cust[i]->set_hotel3("Occidental Sharjah Grand");
												cust[i]->set_stay1(5);
												cust[i]->set_stay2(5);
												cust[i]->set_stay3(4);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											if (opt5 == 2) {
												cust[i]->set_type("Gold");
												cust[i]->set_country("UAE");
												cust[i]->set_city1("Dubai");
												cust[i]->set_city2("Abu Dhabi");
												cust[i]->set_city3("Sharjah");
												cust[i]->set_hotel1("Citymax Hotel");
												cust[i]->set_hotel2("Southern Sun");
												cust[i]->set_hotel3("Verona Resort");
												cust[i]->set_stay1(3);
												cust[i]->set_stay2(3);
												cust[i]->set_stay3(3);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											display_package_purchased();
										}
										if (opt4 == 2) {
											opt5 = display_Turkey();
											if (opt5 == 0) {
												opt4 = 0;
											}
											if (opt5 == 1) {
												cust[i]->set_type("Premium");
												cust[i]->set_country("TURKEY");
												cust[i]->set_city1("ISTANBUL");
												cust[i]->set_city2("ANKARA");
												cust[i]->set_city3("ANTALYA");
												cust[i]->set_hotel1("CVK PARK BOSPHORUS HOTEL");
												cust[i]->set_hotel2("THE WINGS HOTEL ");
												cust[i]->set_hotel3("MAI ANCI HOTEL");
												cust[i]->set_stay1(4);
												cust[i]->set_stay2(4);
												cust[i]->set_stay3(4);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											if (opt5 == 2) {
												cust[i]->set_type("Gold");
												cust[i]->set_country("TURKEY");
												cust[i]->set_city1("ISTANBUL");
												cust[i]->set_city2("ANKARA");
												cust[i]->set_city3("ANTALYA");
												cust[i]->set_hotel1("THE GREEN PARK");
												cust[i]->set_hotel2("RADDISON BLUE");
												cust[i]->set_hotel3("ELIPS ROYAL HOTEL");
												cust[i]->set_stay1(3);
												cust[i]->set_stay2(2);
												cust[i]->set_stay3(3);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											display_package_purchased();
							        }
										if (opt4 == 3) {
                                            opt5 = display_Thailand();
											if (opt5 == 0) {
												opt4 = 0;
											}
											if (opt5 == 1) {
												cust[i]->set_type("Premium");
												cust[i]->set_country("THAILAND");
												cust[i]->set_city1("BANGKOK");
												cust[i]->set_city2("PHUKET");
												cust[i]->set_city3("KO PHI PHI ISLAND");
												cust[i]->set_hotel1("MARRIOT HOTEL");
												cust[i]->set_hotel2("VILLA ZOLITUDE ");
												cust[i]->set_hotel3("SAii Phi Phi Island Village");
												cust[i]->set_stay1(4);
												cust[i]->set_stay2(4);
												cust[i]->set_stay3(4);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											if (opt5 == 2) {
												cust[i]->set_type("Gold");
												cust[i]->set_country("THAiLAND");
												cust[i]->set_city1("BANGKOK");
												cust[i]->set_city2("PHUKET");
												cust[i]->set_city3("KO PHI PHI ISLAND");
												cust[i]->set_hotel1("KEPLER RESIDENCE");
												cust[i]->set_hotel2("NOVOTEL");
												cust[i]->set_hotel3("HIP Seaview Resort ");
												cust[i]->set_stay1(3);
												cust[i]->set_stay2(2);
												cust[i]->set_stay3(3);
												cust[i]->set_flight_date1("Ali gadhe function bana");
												cust[i]->set_flight_date2("Ali gadhe function bana");
												cust[i]->set_flight_date3("Ali gadhe function bana");
												cust[i]->set_flight_date4("Ali gadhe function bana");
												cust[i]->set_flight_time1("Ali gadhe function bana");
												cust[i]->set_flight_time2("Ali gadhe function bana");
												cust[i]->set_flight_time3("Ali gadhe function bana");
												cust[i]->set_flight_time4("Ali gadhe function bana");
												cust[i]->package_purchased();
											}
											display_package_purchased();
										    
										}
									   int opt6=options_screen();
										
										if(opt6==0){
                                           opt4=0;
										}
										else if(opt6==1){
											int opt7;
											cout<<"SELECT FROM FOLLOWING DRIVERS: "<<endl;
											for(int k=0;k<rental::get_count();k++){
											cout<<"DRIVER "<<k<<" INFO:"<<endl<<"NAME: "<<rent[0]->get_name()<<" "<<"RATING: "<<rent[0]->get_rating()<<endl;
											cout<<"ENTER 1 IF you want to select this driver,0 to go to next driver"<<endl;
											cin>>opt7;
											if(opt7==1){
												cust[i]->set_driver(rent[k]->get_name());                                                                  
												break;
											}
	                                        }
											if(opt7==0){
                                              opt6=0;
											}
											if(opt7==1){
												cust[i]->set_driver(rent[0]->get_name());
											}
											if(opt7==2){
												cust[i]->set_driver(rent[1]->get_name());
											}
											if(opt7==3){
												cust[i]->set_driver(rent[0]->get_name());
											}
										}
										else if(opt6==2){
                                        int opt7;
										cout<<"SELECT FROM FOLLOWING GUIDES: "<<endl;
										cout<<"GUIDE 1: "<<endl<<"NAME: "<<tour_guide[0]->get_name()<<" RATING:"<<tour_guide[0]->get_rating()<<endl;
                                        cout<<"GUIDE 2: "<<endl<<"NAME: "<<tour_guide[1]->get_name()<<" RATING:"<<tour_guide[1]->get_rating()<<endl;
										cout<<"GUIDE 3: "<<endl<<"NAME: "<<tour_guide[2]->get_name()<<" RATING:"<<tour_guide[2]->get_rating()<<endl;
										cin>>opt7;
										if(opt7==0){
                                            opt6=0;
										}
										if(opt7==1){
                                    	cust[i]->set_guide(tour_guide[0]->get_name());
										}
										if(opt7==2){
                                        cust[i]->set_guide(tour_guide[1]->get_name());
										}
										if(opt7==3){
                                        cust[i]->set_guide(tour_guide[2]->get_name());
										}
										}

										
						       		 } while (opt4 != 0);
								}
								if (opt3 == 2) {
                                    cout<<"DRIVER INFORMATION: "<<endl<<"NAME: "<<cust[i]->get_driver()<<endl;
									  
								}
								if (opt3 == 3) {
                                   cout<<"TOUR GUIDE INFORMATION: "<<endl<<"NAME: "<<cust[i]->get_guide()<<endl;     
								}
								if (opt3 == 4) {
                                   cust[i]->disp_profile();
								}
								if (opt3 == 5) {
                                 int opt8=options_screen();
								 if(opt8==0){
                                     opt3=0;
								 }
								 if(opt8==1){
                                     cout<<"PLEASE ENTER YOUR NAME: "<<endl;
									 cin>>name;
									 cust[i]->set_name(name);
								 }
								 if(opt8==2){
                                     cout<<"PLEASE ENTER YOUR NEW EMAIL: "<<endl;
									 cin>>email;
									 cust[i]->set_email(email);
								 }
								 if(opt8==3){
									int found=0;
									string pass_verify;
			                       while(found==0){
								    cout<<"PLEASE ENTER YOUR NEW PASSWORD!"<<endl;
                                    cin>>pass;
									cout<<"PLEASE RE-ENTER YOUR NEW PASSWORD: "<<endl;
                                    cin>>pass_verify;
									if(pass_verify==pass){
										cust[i]->set_password(pass);
										found=1;
									}
									else{
										cout<<"PLEASE ENTER MATCHING PASSWORDS"<<endl;
									}
								   }
								 }
								 if(opt8==4){
                                         cout<<"PLEASE ENTER YOUR NEW CONTACT NUMBER: "<<endl;
										 cin>>num;
										 cust[i]->set_num(num);
								 }
								 if(opt8==5){
                                         cout<<"PLEASE ENTER YOUR NEW EMAIL: "<<endl;
										 cin>>email;
										 cust[i]->set_email(email);
								 }
								}
								if (opt3 == 6) {
                                cust[i]->display_package();
								}
								
							} while (opt3 != 0);
						}
					}
				} while (opt2 != 0);
			}
			if (opt == 3) {
				opt2 = second_screen();
				system("cls");
			}
			if (opt == 4) {
				opt2 = second_screen();
				system("cls");
			}
			if (opt == 5) {
				opt2 = second_screen();
				system("cls");
			}
			if (opt == 6) {
				opt2 = second_screen();
				system("cls");
			}
		} while (opt2 != 0);
	} while (opt != 0);
}

class guide {
	string name;
	string password;
	int rating;
	static int guide_count;
public:
	guide(string n, string p, int r) {
		name = n;
		password = p;
		rating = r;
		guide_count++;
		
	}
	string get_name() {
		return name;
	}
	int get_rating(){
		return rating;
	}
	void disp_guide(){
		cout<<"NAME: "<<name<<endl;
		cout<<"RATING: "<<rating<<endl;
	}
 static int get_gcount(){
	return guide_count;
 }
};
int guide::guide_count=0;

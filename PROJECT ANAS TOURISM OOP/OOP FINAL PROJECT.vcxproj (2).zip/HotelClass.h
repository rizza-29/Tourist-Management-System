class hotel {
	string name;
	string password;
	int rating;
public:
	hotel(string n, string p, int r) {
		name = n;
		password = p;
		rating = r;
	}
	string get_name() {
		return name;
	}
};


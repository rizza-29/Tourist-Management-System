using namespace std;
class airline {
	string com_name;
	string password;
	int rating;
public:
	airline(string n, string p, int r) {
		com_name = n;
		password = p;
		rating = r;
	}
	string get_name() {
		return com_name;
	}
};

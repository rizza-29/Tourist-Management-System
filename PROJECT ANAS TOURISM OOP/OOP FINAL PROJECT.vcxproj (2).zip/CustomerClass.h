class package {
protected:
	string country;
	string city[3];
	string hotel[3];
	int stay[3];
	string guide;
	string driver;
	string date[4];
	string time[4];
	string type;
	bool purchased;
	bool add_driver;
	bool add_guide;
public:
	package() {
		purchased = false;
		add_driver = false;
		add_guide = false;
	}
	void set_country(string c) {
		country = c;
	}
	void set_city1(string c1) {
		city[0] = c1;
	}
	void set_city2(string c2) {
		city[1] = c2;
	}
	void set_city3(string c3) {
		city[2] = c3;
	}
	void set_hotel1(string h1) {
		hotel[0] = h1;
	}
	void set_hotel2(string h2) {
		hotel[1] = h2;
	}
	void set_hotel3(string h3) {
		hotel[2] = h3;
	}
	void set_stay1(int s1) {
		stay[0] = s1;
	}
	void set_stay2(int s2) {
		stay[1] = s2;
	}
	void set_stay3(int s3) {
		stay[2] = s3;
	}
	void set_guide(string g) {
		guide = g;
	}
	void set_driver(string d) {
		driver = d;
	}
	string get_driver(){
		return driver;
	}
	string get_guide(){
		return guide;
	}
	void set_flight_date1(string d1) {
		date[0] = d1;
	}
	void set_flight_date2(string d2) {
		date[1] = d2;
	}
	void set_flight_date3(string d3) {
		date[2] = d3;
	}
	void set_flight_date4(string d4) {
		date[3] = d4;
	}
	void set_flight_time1(string t1) {
		time[0] = t1;
	}
	void set_flight_time2(string t2) {
		time[1] = t2;
	}
	void set_flight_time3(string t3) {
		time[2] = t3;
	}
	void set_flight_time4(string t4) {
		time[3] = t4;
	}
	void set_type(string t) {
		type = t;
	}
	void package_purchased() {
		purchased = true;
	}
	void driver_added() {
		add_driver = true;
	}
	void guide_added() {
		add_guide = true;
	}
	void display_package() {
		if (purchased == true) {
			cout << endl << "\t\t\t**YOUR PACKAGE**" << endl;
			cout << "\t**COUNTRY:" << country << "**" << endl;
			for (int i = 0;i < 3;i++) {
				cout << endl << "\t**CITY:" << city[i] << "**" << endl;
				cout << "\t**Date of Departure to the City:" << date[i] << "**" << endl;
				cout << "\t**Time of Departure to the City:" << time[i] << "**" << endl;
				cout << "\t**HOTEL:" << hotel[i] << "**" << endl;
				cout << "\t**Number of days of stay:" << stay[i] << "**" << endl;
			}
			cout << endl << "Date of return to Homeland:" << date[3] << endl;
			cout << "Time of return to Homeland:" << time[3] << endl;
			if (add_guide == true) {
				cout << endl << "\t**Tour Guide:" << guide << "**" << endl;
			}
			else {
				cout << endl << "\t**Tour Guide:NOT ADDED IN PACKAGE**" << endl;
			}
			if (add_driver == true) {
				cout << "\t**Car Rental Driver:" << driver << "**" << endl;
			}
			else {
				cout << endl << "\t**Car Rental Driver:NOT ADDED IN PACKAGE**" << endl;
			}
		}
	}
};

class customer:public package {
	string name;
	string password;
	string email;
	string username;
	int phone_num;
	static int count;
public:
	customer(string n, string p, string e, int ph, string u):package() {
		name = n;
		password = p;
		email = e;
		phone_num = ph;
		username = u;
		count++;
	}
	void disp_profile(){
		cout<<"PROFILE: "<<endl;
		cout<<"NAME: "<<name<<endl;
		cout<<"EMAIL: "<<email<<endl;
		cout<<"PHONE NUMBER: "<<phone_num<<endl;
		cout<<"USERNAME: "<<username<<endl;
	}
	void set_name(string n){
     name=n;
	}
	void set_email(string e){
    email=e;
	}
	void set_username(string u){
     username=u;
	}
	void set_password(string p){
    password=p;
	}
    void set_num(int n){
    phone_num=n;
	}
	string get_name() {
		return name;
	}
	static int get_count() {
		return count;
	}
	bool verify(string u_name) {
		string pass;
		if (username == u_name) {
			cout << "Enter password of Customer " << name << ":";
			cin >> pass;
			if (pass == password) {
				return true;
			}
			else {
				int j = 3;
				while (password != pass || j > 0) {
					cout << "Incorrect Password!Enter Again(" << j << " tries left):" << endl;
					cin >> pass;
					if (pass == password) {
						return true;
					}
					else {
						j--;
					}
				}
				return false;
			}
		}
		else {
			return false;
		}
	}

};
int customer::count = 0;

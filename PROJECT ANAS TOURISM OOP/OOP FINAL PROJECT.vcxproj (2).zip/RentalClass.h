class rental {
	string com_name;
	string password;
	int rating;
	static int count;
public:
	rental(string n, string p, int r) {
		com_name = n;
		rating = r;
		password=p;
		count++;
	}
	string get_name() {
		return com_name;
	}
	int get_rating(){
		return rating;
	}
	void disp_rental(){
		cout<<"NAME: "<<com_name<<endl;
		cout<<"RATING: "<<rating<<endl;
	}
	static int get_count(){
		return count;
	}
};
int rental::count=0;
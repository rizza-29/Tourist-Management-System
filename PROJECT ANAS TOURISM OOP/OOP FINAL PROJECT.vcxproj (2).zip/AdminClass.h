class admin {
	string name;
	string username;
	string password;
	int ID;
	static int count;
public:
	admin(string n, string p,string u) {
		name = n;
		password = p;
		username = u;
		count++;
		ID = count;
	}
	string get_name() {
		return name;
	}
	string get_username() {
		return username;
	}
	void set_name(string n) {
		name = n;
	}
	void set_password(string p) {
		password = p;
	}
	static int get_count() {
		return count;
	}
	bool verify(string u_name) {
		string pass;
		if (username == u_name) {
			cout << "Enter password of Admin " << name << ":";
			cin >> pass;
			if (pass == password) {
				return true;
			}
			else {
				int j = 3;
				while (password != pass || j > 0) {
					cout << "Incorrect Password!Enter Again(" << j << " tries left):" << endl;
					cin >> pass;
					if (pass == password) {
						return true;
					}
					else {
						j--;
					}
				}
				return false;
			}
		}
		else {
			return false;
		}
	}
};
int admin::count = 0;